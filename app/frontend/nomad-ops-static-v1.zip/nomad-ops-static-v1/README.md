# NOMAD Ops — Static Prototype v1

Static, navigable prototype for Asteria Manufacturing Group.

## What works
- Overview dashboard
- Sidebar navigation across all planned modules
- Fake enterprise data
- Action buttons/toasts
- Command bar interaction
- Cmd/Ctrl + K focus
- Light / dark switch
- Responsive layout

## What is intentionally NOT connected yet
- Backend / FastAPI
- PostgreSQL
- Qdrant / RAG
- n8n
- LLM APIs
- Authentication / permissions
- Real observability

## Run
Open `index.html` directly in a browser, or serve the folder with any static web server.
