
window.NOMAD_DATA = {
  metrics: [
    {title:"Incidents", value:"7", sub:"2 critical · 5 in progress", tone:"red", icon:"△"},
    {title:"Approvals", value:"4", sub:"2 pending (IT) · 2 pending (Ops)", tone:"amber", icon:"◎"},
    {title:"Knowledge health", value:"94%", sub:"3 outdated docs · 1 broken link", tone:"blue", icon:"▤"},
    {title:"New documents", value:"13", sub:"11 classified · 2 pending review", tone:"green", icon:"▧"},
    {title:"AI spend (today)", value:"€18.42", sub:"−12% vs yesterday · 1,842 requests", tone:"purple", icon:"◉"}
  ],
  actions: [
    {sev:"Critical",sevClass:"critical",title:"Plant 2 packaging line stopped",desc:"Similar incidents found · Suggested actions available",dept:"Production<br/>Plant 2",btn:"Investigate",thumb:""},
    {sev:"High",sevClass:"high",title:"Supplier contract received",desc:"Classification proposed · Review and confirm",dept:"Procurement<br/>Finance",btn:"Review",thumb:"doc"},
    {sev:"Medium",sevClass:"medium",title:"New employee access package",desc:"Manager approval required · 3 systems",dept:"HR<br/>Onboarding",btn:"Approve",thumb:"user"},
    {sev:"Normal",sevClass:"normal",title:"Laptop not connecting to VPN",desc:"Suggested solution found · User notified",dept:"IT Support<br/>Remote Access",btn:"View",thumb:"it"},
    {sev:"Normal",sevClass:"normal",title:"Monthly safety report (PDF)",desc:"Document processed · 8 insights extracted",dept:"HSE<br/>Compliance",btn:"View",thumb:"pdf"}
  ],
  activity: [
    ["12:26","Knowledge source updated","VPN_Procedure_v3.pdf"],
    ["11:48","Automation executed","Create IT ticket (#4581)"],
    ["10:31","Document classified","Supplier_Contract_ACME.pdf"],
    ["09:12","Agent suggestion accepted","Restart print server"],
    ["08:47","Process analysis completed","Employee onboarding"]
  ],
  workflows: [
    ["01","IT Incident Copilot","Diagnose · Solve · Escalate"],
    ["02","Knowledge Search","Find · Summarize · Cite sources"],
    ["03","Attachment Intelligence","Extract · Classify · Route"],
    ["04","Operational Agent","Use tools · Run flows · Get things done"],
    ["05","Process Analyzer","Find opportunities · Estimate impact"]
  ]
}
