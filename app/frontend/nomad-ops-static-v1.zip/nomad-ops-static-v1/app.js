
const D = window.NOMAD_DATA;
const content = document.getElementById("content");
const nav = document.getElementById("nav");
const toast = document.getElementById("toast");
const commandInput = document.getElementById("commandInput");

function showToast(msg){
  toast.textContent = msg;
  toast.classList.add("show");
  setTimeout(()=>toast.classList.remove("show"),1800);
}

function overview(){
  content.innerHTML = `
    <section class="hero">
      <div class="hero-kicker">ASTERIA MANUFACTURING GROUP</div>
      <h1>Keep operations moving.</h1>
      <p>Real problems. Real context. Real AI.</p>
      <div class="hero-note">Same people.<br/>Higher potential.</div>
    </section>

    <section class="metrics">
      ${D.metrics.map(m=>`
        <article class="metric ${m.tone}">
          <div class="metric-top">
            <div class="metric-icon">${m.icon}</div>
            <div class="metric-title">${m.title}</div>
          </div>
          <div class="metric-value">${m.value}</div>
          <div class="metric-sub">${m.sub}</div>
        </article>
      `).join("")}
    </section>

    <section class="grid-main">
      <article class="card">
        <div class="card-header"><h3>● &nbsp;Action required</h3><button class="link-btn" data-toast="Opening action queue…">View all →</button></div>
        <div class="action-list">
          ${D.actions.map(a=>`
          <div class="action-row">
            <div class="thumb ${a.thumb}"></div>
            <div>
              <div><span class="severity ${a.sevClass}">${a.sev}</span><span class="action-title">${a.title}</span></div>
              <div class="action-desc">${a.desc}</div>
            </div>
            <div class="dept">${a.dept}</div>
            <button class="action-btn" data-toast="${a.btn}: demo interaction">${a.btn}</button>
            <button class="more" data-toast="More options">•••</button>
          </div>`).join("")}
        </div>
      </article>

      <div class="side-stack">
        <article class="card readiness">
          <h3>✣ &nbsp;AI readiness spotlight</h3>
          <div class="process-title">Process: Supplier invoices</div>
          <div class="process-sub">Good candidate for partial automation</div>
          <div class="bar"><div class="seg1"></div><div class="seg2"></div><div class="seg3"></div></div>
          <div class="legend">
            <span><i style="background:#4ea86c"></i>58% Automation</span>
            <span><i style="background:#7296db"></i>22% LLM</span>
            <span><i style="background:#c8ced3"></i>20% Human</span>
          </div>
          <div class="quote-box">“Automate the repetitive. Augment the complex. Keep humans in control.”</div>
        </article>

        <article class="card">
          <div class="card-header"><h3>Recent activity</h3><button class="link-btn" data-toast="Opening activity log…">View all →</button></div>
          <div class="activity">
            ${D.activity.map(x=>`<div class="activity-row"><div class="time">${x[0]}</div><div><strong>${x[1]}</strong><br>${x[2]}</div></div>`).join("")}
          </div>
        </article>
      </div>
    </section>

    <section class="lower">
      <article class="card workflows">
        <div class="card-header" style="padding:0 0 12px"><h3>Core workflows</h3><button class="link-btn" data-toast="Opening workflows…">Go to module →</button></div>
        <div class="workflow-grid">
          ${D.workflows.map(w=>`<div class="workflow"><div class="workflow-num">${w[0]}</div><div class="workflow-title">${w[1]}</div><div class="workflow-sub">${w[2]}</div></div>`).join("")}
        </div>
      </article>

      <article class="card costs">
        <div class="card-header" style="padding:0"><h3>AI costs & models</h3><button class="link-btn" data-toast="Opening cost breakdown…">View details →</button></div>
        <div class="donut"></div>
        <div class="cost-list">
          Claude 3.5 — 42%<br/>
          GPT-4o — 28%<br/>
          Qwen3 (local) — 18%<br/>
          Other — 12%
        </div>
      </article>

      <article class="card status">
        <div class="card-header" style="padding:0 0 8px"><h3>System status</h3><span class="pill">All systems operational</span></div>
        ${["API (FastAPI)","n8n (Automations)","PostgreSQL","Qdrant (RAG)","VPS (Hostinger)"].map(s=>`<div class="status-row"><span><i class="dot"></i>${s}</span><span>Operational</span></div>`).join("")}
      </article>
    </section>
  `;
  wireToasts();
}

const modules = {
  incidents: {
    title:"Incidents",
    sub:"Diagnose, compare historical cases, suggest actions and escalate when needed.",
    rows:[
      ["Plant 2 packaging line stopped","Critical · Production · 12:14","Investigating"],
      ["Laptop not connecting to VPN","Normal · IT Support · 08:27","Suggested fix"],
      ["Label printer queue blocked","High · Warehouse · Yesterday","Awaiting approval"]
    ]
  },
  knowledge:{
    title:"Knowledge",
    sub:"Search enterprise knowledge with traceable sources, versions and ownership.",
    rows:[
      ["VPN Procedure v3","IT · Updated today","Healthy"],
      ["Supplier onboarding policy","Finance · Updated 12 days ago","Healthy"],
      ["Plant 2 emergency runbook","Operations · Updated 94 days ago","Review"]
    ]
  },
  documents:{
    title:"Documents",
    sub:"Classify incoming documents, extract metadata and route them to the right process.",
    rows:[
      ["Supplier_Contract_ACME.pdf","Contract · Procurement","Pending review"],
      ["Safety_Report_August.pdf","HSE report · Compliance","Processed"],
      ["Invoice_90218.pdf","Invoice · Finance","Classified"]
    ]
  },
  automations:{
    title:"Automations",
    sub:"Run deterministic workflows where AI is not needed, and combine them with agents where it is.",
    rows:[
      ["Create IT ticket","n8n · IT Operations","Active"],
      ["Classify supplier attachments","n8n + LLM · Procurement","Active"],
      ["Employee onboarding","n8n · HR","Human approval"]
    ]
  },
  analysis:{
    title:"AI Analysis",
    sub:"Decide whether a process should use rules, automation, an LLM, human review — or no AI at all.",
    rows:[
      ["Supplier invoices","58% workflow · 22% LLM · 20% human","Recommended"],
      ["Employee onboarding","72% workflow · 8% LLM · 20% human","Recommended"],
      ["Password reset","85% workflow · 0% LLM · 15% human","Avoid LLM"]
    ]
  },
  governance:{
    title:"Governance",
    sub:"Track model access, sensitive actions, approvals, auditability and policy compliance.",
    rows:[
      ["Sensitive action policy","IT / Security","Enforced"],
      ["Human approval threshold","Risk score ≥ 70","Enforced"],
      ["External model access","Finance documents","Restricted"]
    ]
  },
  costs:{
    title:"Costs & Usage",
    sub:"Understand what each model, workflow and business operation is costing.",
    rows:[
      ["Claude 3.5","42% of LLM spend","€7.74 today"],
      ["GPT-4o","28% of LLM spend","€5.16 today"],
      ["Qwen3 local","18% of AI requests","€0 API cost"]
    ]
  }
};

function moduleView(key){
  const m = modules[key];
  content.innerHTML = `
    <h1 class="view-title">${m.title}</h1>
    <div class="view-sub">${m.sub}</div>
    <div class="module-list">
      ${m.rows.map(r=>`
        <article class="card module-row">
          <div><h4>${r[0]}</h4><p>${r[1]}</p></div>
          <span class="pill">${r[2]}</span>
        </article>
      `).join("")}
      <article class="card empty-panel">Static prototype — backend connection comes in the next phase.</article>
    </div>
  `;
}

function wireToasts(){
  document.querySelectorAll("[data-toast]").forEach(el=>{
    el.addEventListener("click",()=>showToast(el.dataset.toast));
  });
}

nav.addEventListener("click", e=>{
  const btn = e.target.closest(".nav-item");
  if(!btn) return;
  document.querySelectorAll(".nav-item").forEach(x=>x.classList.remove("active"));
  btn.classList.add("active");
  const view = btn.dataset.view;
  if(view==="overview") overview(); else moduleView(view);
});

commandInput.addEventListener("keydown",e=>{
  if(e.key==="Enter" && commandInput.value.trim()){
    showToast(`Command captured: "${commandInput.value.trim()}"`);
    commandInput.value="";
  }
});

document.getElementById("themeBtn").addEventListener("click",()=>document.body.classList.toggle("dark"));

document.addEventListener("keydown",e=>{
  if((e.ctrlKey||e.metaKey) && e.key.toLowerCase()==="k"){
    e.preventDefault();
    commandInput.focus();
  }
});

overview();
